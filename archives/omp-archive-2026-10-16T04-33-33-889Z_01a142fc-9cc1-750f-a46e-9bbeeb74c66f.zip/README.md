# Session archive

Generated 2026-10-16T14:31:12.630Z from session `01a142fc-9cc1-750f-a46e-9bbeeb74c66f`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

1 completed job recovered from the transcripts (main + every subagent); full list in `jobs.json`. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (2)

- `AndroidCamApp` — 155 entries, 1025536 bytes
- `RustDeskApp` — 316 entries, 1459716 bytes

## Totals

23 files, 8329852 bytes.

Omitted:
- Live agent/job snapshots (agents.json jobs field, jobs.json live field): the session was archived from outside the running omp process, so only state recovered from transcripts is included.

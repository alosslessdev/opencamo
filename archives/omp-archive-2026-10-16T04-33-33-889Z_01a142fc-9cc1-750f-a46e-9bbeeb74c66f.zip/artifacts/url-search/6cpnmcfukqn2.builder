---
canonical: https://developer.android.com/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder
meta-google-signin-client-id: 721724668570-nbkv1cfusk7kk4eni4pjvepaus73b13t.apps.googleusercontent.com
meta-google-signin-scope: profile email https://www.googleapis.com/auth/developerprofiles https://www.googleapis.com/auth/developerprofiles.award https://www.googleapis.com/auth/devprofiles.full_control.firstparty
meta-og:locale: en
meta-og:site_name: Android Developers
meta-og:title: ResolutionSelector.Builder  |  API reference  |  Android Developers
meta-og:type: website
meta-og:url: https://developer.android.com/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder
meta-theme-color: #34a853
meta-viewport: width=device-width, initial-scale=1
title: ResolutionSelector.Builder &nbsp;|&nbsp; API reference &nbsp;|&nbsp; Android Developers
---

[![Android Developers](https://www.gstatic.com/devrel-devsite/prod/v9ce9cb5b22b62a465ff52c45061a0a6a2d86a80b685e9aa8a182b203fdfbf420/android/images/lockup.png)](/)

- English
- Deutsch
- Español – América Latina
- Français
- Indonesia
- Polski
- Português – Brasil
- Tiếng Việt
- 中文 – 简体
- 日本語
- 한국어
[Android Studio](https://developer.android.com/studio) Sign in

- [API reference](https://developer.android.com/reference)

# ResolutionSelector.Builder

Artifact: [androidx.camera:camera-core](/jetpack/androidx/releases/camera)

[View Source](https://cs.android.com/search?q=file:androidx/camera/core/resolutionselector/ResolutionSelector.java+class:androidx.camera.core.resolutionselector.ResolutionSelector.Builder)

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

---

Kotlin |[Java](/reference/androidx/camera/core/resolutionselector/ResolutionSelector.Builder "View this page in Java")

```
class [ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)
```

---

Builder for a `[ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)`.

## Summary

| Public constructors                                                                                                                       |
| ----------------------------------------------------------------------------------------------------------------------------------------- |
| `[Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#Builder())()` Creates a Builder instance. |

| Public functions                                                                                                     |                                                                                                                                                                                                          |
| -------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `[ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)`                 | `[build](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#build())()` Builds the resolution selector.                                                                |
| `[ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)` | `[setAllowedResolutionMode](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setAllowedResolutionMode(int))(mode: [Int](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-int/index.html))` Sets the allowed resolution mode. |
| `[ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)` | `[setAspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setAspectRatioStrategy(androidx.camera.core.resolutionselector.AspectRatioStrategy))(aspectRatioStrategy: [AspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy))` Sets the aspect ratio selection strategy for the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`. |
| `[ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)` | `[setResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setResolutionFilter(androidx.camera.core.resolutionselector.ResolutionFilter))(resolutionFilter: [ResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionFilter))` Sets the resolution filter to output the final desired sizes list. |
| `[ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)` | `[setResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setResolutionStrategy(androidx.camera.core.resolutionselector.ResolutionStrategy))(resolutionStrategy: [ResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionStrategy))` Sets the resolution selection strategy for the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`. |

## Public constructors

### Builder

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
[Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#Builder())()
```

Creates a Builder instance.

## Public functions

### build

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
fun [build](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#build())(): [ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)
```

Builds the resolution selector. This will create a resolution selector that can be used to select the desired resolution for the captured image.

### setAllowedResolutionMode

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
fun [setAllowedResolutionMode](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setAllowedResolutionMode(int))(mode: [Int](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-int/index.html)): [ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)
```

Sets the allowed resolution mode.

If not specified, the default setting is `[PREFER_CAPTURE_RATE_OVER_HIGHER_RESOLUTION](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector#PREFER_CAPTURE_RATE_OVER_HIGHER_RESOLUTION())`.

### setAspectRatioStrategy

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
fun [setAspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setAspectRatioStrategy(androidx.camera.core.resolutionselector.AspectRatioStrategy))(aspectRatioStrategy: [AspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy)): [ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)
```

Sets the aspect ratio selection strategy for the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`. The aspect ratio selection strategy determines how the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)` will choose the aspect ratio of the captured image.

If the aspect ratio strategy is not specified, `[RATIO_4_3_FALLBACK_AUTO_STRATEGY](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy#RATIO_4_3_FALLBACK_AUTO_STRATEGY())` will be used as the default.

`[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`s can be bound by a `[UseCaseGroup](/reference/kotlin/androidx/camera/core/UseCaseGroup)` with a `[ViewPort](/reference/kotlin/androidx/camera/core/ViewPort)` setting. If a `[ViewPort](/reference/kotlin/androidx/camera/core/ViewPort)` is set, it is recommended that the `[ViewPort](/reference/kotlin/androidx/camera/core/ViewPort)` and the bound `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`s should have matching aspect ratio settings. Otherwise, the output crop rectangles may be double-cropped from the full camera sensor field of view. See `[ViewPort.Builder](/reference/kotlin/androidx/camera/core/ViewPort.Builder)` for details.

CameraX only supports the common 4:3 and 16:9 aspect ratio settings. Some devices may offer additional output sizes. To access these, you'll need to create a `[ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)` with a `[ResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionFilter)` to find and select those specific sizes.

### setResolutionFilter

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
fun [setResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setResolutionFilter(androidx.camera.core.resolutionselector.ResolutionFilter))(resolutionFilter: [ResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionFilter)): [ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)
```

Sets the resolution filter to output the final desired sizes list. The resolution filter will filter out unsuitable sizes and sort the resolution list in the preferred order. The preferred order is the order in which the resolutions should be tried first.

### setResolutionStrategy

Added in [1.3.0](/jetpack/androidx/releases/camera#1.3.0)

```
fun [setResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder#setResolutionStrategy(androidx.camera.core.resolutionselector.ResolutionStrategy))(resolutionStrategy: [ResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionStrategy)): [ResolutionSelector.Builder](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector.Builder)
```

Sets the resolution selection strategy for the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`. The resolution selection strategy determines how the `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)` will choose the resolution of the captured image.

Note: `[ResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionStrategy)` works in conjunction with `[AspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy)` and the default `[AspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy)` is `[RATIO_4_3_FALLBACK_AUTO_STRATEGY](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy#RATIO_4_3_FALLBACK_AUTO_STRATEGY())`. Ensure you set a corresponding `[AspectRatioStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy)` alongside your `[ResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionStrategy)`. For example, if your `[ResolutionStrategy](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionStrategy)` uses a bound size of `1920x1080` and a 16:9 aspect ratio is preferred, set `[RATIO_16_9_FALLBACK_AUTO_STRATEGY](/reference/kotlin/androidx/camera/core/resolutionselector/AspectRatioStrategy#RATIO_16_9_FALLBACK_AUTO_STRATEGY())` when building the `[ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)`.

CameraX only supports the common 4:3 and 16:9 aspect ratio settings. To select resolution of other aspect ratios, you'll need to create a `[ResolutionSelector](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionSelector)` with a `[ResolutionFilter](/reference/kotlin/androidx/camera/core/resolutionselector/ResolutionFilter)` to find and select those specific sizes.

Content and code samples on this page are subject to the licenses described in the [Content License](/license). Java and OpenJDK are trademarks or registered trademarks of Oracle and/or its affiliates.

Last updated 2026-06-24 UTC.
---
canonical: https://developer.android.com/reference/kotlin/androidx/camera/core/CameraSelector.Builder
meta-google-signin-client-id: 721724668570-nbkv1cfusk7kk4eni4pjvepaus73b13t.apps.googleusercontent.com
meta-google-signin-scope: profile email https://www.googleapis.com/auth/developerprofiles https://www.googleapis.com/auth/developerprofiles.award https://www.googleapis.com/auth/devprofiles.full_control.firstparty
meta-og:locale: en
meta-og:site_name: Android Developers
meta-og:title: CameraSelector.Builder  |  API reference  |  Android Developers
meta-og:type: website
meta-og:url: https://developer.android.com/reference/kotlin/androidx/camera/core/CameraSelector.Builder
meta-theme-color: #34a853
meta-viewport: width=device-width, initial-scale=1
title: CameraSelector.Builder &nbsp;|&nbsp; API reference &nbsp;|&nbsp; Android Developers
---

[![Android Developers](https://www.gstatic.com/devrel-devsite/prod/v9ce9cb5b22b62a465ff52c45061a0a6a2d86a80b685e9aa8a182b203fdfbf420/android/images/lockup.png)](/)

- English
- Deutsch
- Español – América Latina
- Français
- Indonesia
- Polski
- Português – Brasil
- Tiếng Việt
- 中文 – 简体
- 日本語
- 한국어
[Android Studio](https://developer.android.com/studio) Sign in

- [API reference](https://developer.android.com/reference)

# CameraSelector.Builder

Artifact: [androidx.camera:camera-core](/jetpack/androidx/releases/camera)

[View Source](https://cs.android.com/search?q=file:androidx/camera/core/CameraSelector.java+class:androidx.camera.core.CameraSelector.Builder)

Added in [1.0.0](/jetpack/androidx/releases/camera#1.0.0)

---

Kotlin |[Java](/reference/androidx/camera/core/CameraSelector.Builder "View this page in Java")

```
class [CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)
```

---

Builder for a `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`.

## Summary

| Public constructors                                                                    |
| -------------------------------------------------------------------------------------- |
| `[Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#Builder())()` |

| Public functions                                                                          |                                                                                                                                                                                                          |
| ----------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | `[addCameraFilter](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#addCameraFilter(androidx.camera.core.CameraFilter))(cameraFilter: [CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter))` Adds a `[CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter)` to the current set of filters. |
| `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`                 | `[build](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#build())()` Builds the `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`.                                 |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | `[requireLensFacing](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#requireLensFacing(int))(lensFacing: [Int](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-int/index.html))` Requires a camera with the specified lens facing. |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | `[setPhysicalCameraId](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#setPhysicalCameraId(java.lang.String))(physicalCameraId: [String](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-string/index.html))` Sets the physical camera id. |

## Public constructors

### Builder

Added in [1.0.0](/jetpack/androidx/releases/camera#1.0.0)

```
[Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#Builder())()
```

## Public functions

### addCameraFilter

Added in [1.0.0](/jetpack/androidx/releases/camera#1.0.0)

```
fun [addCameraFilter](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#addCameraFilter(androidx.camera.core.CameraFilter))(cameraFilter: [CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter)): [CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)
```

Adds a `[CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter)` to the current set of filters. It can be used to select a specific camera based on customized criteria like Camera2 characteristics.

Multiple filters can be added. All filters will be applied by the order they were added when the CameraSelector is used, and the first camera output from the filters will be selected.

| Parameters                                                                          |                                                                                                       |
| ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `cameraFilter: [CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter)` | The `[CameraFilter](/reference/kotlin/androidx/camera/core/CameraFilter)` for selecting cameras with. |

| Returns                                                                                   |               |
| ----------------------------------------------------------------------------------------- | ------------- |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | This builder. |

### build

Added in [1.0.0](/jetpack/androidx/releases/camera#1.0.0)

```
fun [build](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#build())(): [CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)
```

Builds the `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`.

### requireLensFacing

Added in [1.0.0](/jetpack/androidx/releases/camera#1.0.0)

```
fun [requireLensFacing](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#requireLensFacing(int))(lensFacing: [Int](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-int/index.html)): [CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)
```

Requires a camera with the specified lens facing.

Valid values for lens facing are `[LENS_FACING_FRONT](/reference/kotlin/androidx/camera/core/CameraSelector#LENS_FACING_FRONT())`, `[LENS_FACING_BACK](/reference/kotlin/androidx/camera/core/CameraSelector#LENS_FACING_BACK())` and `[LENS_FACING_EXTERNAL](/reference/kotlin/androidx/camera/core/CameraSelector#LENS_FACING_EXTERNAL())`. However, requiring `[LENS_FACING_EXTERNAL](/reference/kotlin/androidx/camera/core/CameraSelector#LENS_FACING_EXTERNAL())` is currently experimental and may produce unexpected behaviors.

If lens facing is already set, this will add extra requirement for lens facing instead of replacing the previous setting.

| Parameters                                                                                |                                             |
| ----------------------------------------------------------------------------------------- | ------------------------------------------- |
| `lensFacing: [Int](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-int/index.html)` | The lens facing for selecting cameras with. |

| Returns                                                                                   |               |
| ----------------------------------------------------------------------------------------- | ------------- |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | This builder. |

### setPhysicalCameraId

Added in [1.4.0](/jetpack/androidx/releases/camera#1.4.0)

```
fun [setPhysicalCameraId](/reference/kotlin/androidx/camera/core/CameraSelector.Builder#setPhysicalCameraId(java.lang.String))(physicalCameraId: [String](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-string/index.html)): [CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)
```

Sets the physical camera id.

A logical camera is a grouping of two or more of those physical cameras. See [Multi-camera API](https://developer.android.com/media/camera/camera2/multi-camera)

If we want to open one physical camera, for example ultra wide, we just need to set physical camera id in CameraSelector and bind to lifecycle. All CameraX features will work normally when only a single physical camera is used.

If we want to open multiple physical cameras, we need to have multiple `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`s and set physical camera id on each, then bind to lifecycle with the `[CameraSelector](/reference/kotlin/androidx/camera/core/CameraSelector)`s. Internally each physical camera id will be set on `[UseCase](/reference/kotlin/androidx/camera/core/UseCase)`, for example, `[Preview](/reference/kotlin/androidx/camera/core/Preview)` and call `[setPhysicalCameraId](https://developer.android.com/reference/android/hardware/camera2/params/OutputConfiguration.html#setPhysicalCameraId(java.lang.String))`.

Currently only two physical cameras for the same logical camera id are allowed and the device needs to support physical cameras by checking `[isLogicalMultiCameraSupported](/reference/kotlin/androidx/camera/core/CameraInfo#isLogicalMultiCameraSupported())`. In addition, there is no guarantee or API to query whether the device supports multiple physical camera opening or not. Internally the library checks `[isSessionConfigurationSupported](https://developer.android.com/reference/android/hardware/camera2/CameraDevice.html#isSessionConfigurationSupported(android.hardware.camera2.params.SessionConfiguration))`, if the device does not support the multiple physical camera configuration, `[IllegalArgumentException](https://developer.android.com/reference/java/lang/IllegalArgumentException.html)` will be thrown when binding to lifecycle.

| Parameters                                                                                            |                     |
| ----------------------------------------------------------------------------------------------------- | ------------------- |
| `physicalCameraId: [String](https://kotlinlang.org/api/core/kotlin-stdlib/kotlin/-string/index.html)` | Physical camera id. |

| Returns                                                                                   |               |
| ----------------------------------------------------------------------------------------- | ------------- |
| `[CameraSelector.Builder](/reference/kotlin/androidx/camera/core/CameraSelector.Builder)` | this builder. |

Content and code samples on this page are subject to the licenses described in the [Content License](/license). Java and OpenJDK are trademarks or registered trademarks of Oracle and/or its affiliates.

Last updated 2026-08-12 UTC.
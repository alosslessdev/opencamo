{
  "status": "complete",
  "files": [
    "desktop/Cargo.toml",
    "desktop/Cargo.lock",
    "desktop/README.md",
    "desktop/src/main.rs",
    "desktop/src/protocol.rs",
    "desktop/src/stream.rs",
    "desktop/src/loopback.rs",
    "desktop/src/app.rs",
    "desktop/src/selftest.rs"
  ],
  "build": "cargo build --release succeeds, zero warnings/errors (egui/eframe 0.27.2, ureq 2.12.1 json, image 0.25.10, v4l 0.14.0, crossbeam-channel 0.5, parking_lot 0.12, anyhow)",
  "selftest": "opencamo-desktop --selfstream <url> <n_frames> headless (no eframe init); verified against a local mock multipart MJPEG server: 30 frames decoded exit 0 with stats (resolution/bytes/fps/decode-ms), connection-refused exit 1, HTTP 400 JSON error surfaced as 'HTTP 400: unsupported resolution' exit 1, bad/missing args exit 2; accepts full /v1/stream URL (query preserved), bare origin, or origin with port (default 47777 appended)",
  "architecture": "background thread owns HTTP socket read loop; Content-Length multipart parser per PROTOCOL.md (--frame boundary, CRLF framing); JPEG decoded to RGB8 on that thread; bounded(1) channels with producer-side eviction (latest-frame-wins drop) feed UI + loopback writer; UI polls channel and re-uploads texture at most every 33ms; loopback thread negotiates YUYV via VIDIOC_S_FMT (VIDEO_OUTPUT) and writes one frame per write() — matches v4l2loopback kernel driver semantics (verified against driver source)",
  "ui": "connect field + Connect button (capabilities fetched on worker thread), device name/protocol line, camera + WxH@fps resolution combos, Apply re-requests /v1/stream, Disconnect, preview scaled to fit, right panel loopback device dropdown (scan /dev/video* + VIDIOC_QUERYCAP card names) with Rescan/Enable/Disable and actionable 'modprobe v4l2loopback' hints, status bar with connection state + delivered/decode/loopback FPS",
  "notes": [
    "Found and fixed a real URL bug during testing: normalize_base previously appended :47777 to path-bearing inputs; now strips scheme case-insensitively, keeps only the authority, and ensure_stream_url matches on parsed path instead of substring",
    "Frame IDs come from the cumulative delivered counter so UI dedupe survives reconnects",
    "Do NOT run the GUI on this machine (no display) — main agent should only re-run cargo build --release if needed"
  ],
  "checks_for_main": [
    "cargo build --release in desktop/ (already green)",
    "exercise --selftest against the mock server",
    "do not run the GUI"
  ]
}